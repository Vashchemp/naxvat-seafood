# 🚀 Инструкция по запуску Telegram-бота Naxvat SeaFood

## Вариант 1: Запуск прямо сейчас (на компьютере)

### Шаг 1: Установите Python
Скачайте с https://python.org (версия 3.8 или выше)

### Шаг 2: Откройте терминал и перейдите в папку с ботом
```bash
cd /workspace/telegram_bot
```

### Шаг 3: Установите зависимости
```bash
pip install python-telegram-bot
```

### Шаг 4: Запустите бота
```bash
python main.py
```

✅ Бот запустится и будет работать!

---

## Вариант 2: Запуск на сервере (VPS/хостинг)

### 1. Загрузите файлы на сервер
Через FTP или Git:
```bash
git clone <ваш-репозиторий>
cd telegram_bot
```

### 2. Установите зависимости
```bash
pip install -r requirements.txt
```

### 3. Запустите в фоновом режиме
```bash
nohup python main.py > bot.log 2>&1 &
```

### 4. Проверьте работу
```bash
tail -f bot.log
```

---

## Вариант 3: Запуск с вебхуком (рекомендуется для продакшна)

В файле `main.py` замените запуск на:

```python
import os
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

# Вебхук URL (получите на хостинге)
WEBHOOK_URL = "https://ваш-домен.com/webhook"

async def webhook(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработка веб-хука"""
    # ... ваш код обработки

if __name__ == "__main__":
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    
    # Запуск на вебхуке
    app.run_webhook(
        listen="0.0.0.0",
        port=8443,
        url_path="webhook",
        webhook_url=WEBHOOK_URL
    )
```

---

## 📱 После запуска

1. Откройте Telegram
2. Найдите бота: **@naxvatseafood_manager**
3. Нажмите **Start** или отправьте `/start`
4. Общайтесь с AI-агентом!

---

## 🐛 Если бот не отвечает

1. Проверьте токен в `bot_config.py`
2. Убедитесь, что бот запущен (нет ошибок в консоли)
3. Проверьте интернет-соединение
4. Перезапустите бота

---

## 📞 Поддержка

Возникли вопросы? Напишите @naxvatseafood_manager
