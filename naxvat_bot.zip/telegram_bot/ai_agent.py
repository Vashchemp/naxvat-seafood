#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Naxvat SeaFood AI Agent
Telegram Bot with AI capabilities for seafood shop

Author: Naxvat SeaFood
Version: 1.0.0
"""

import os
import sys
import json
import time
import logging
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass, field

# Добавляем путь для импорта модулей
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════
# КОНФИГУРАЦИЯ
# ═══════════════════════════════════════════════════════════════

try:
    from bot_config import BOT_TOKEN, OWNER_CHAT_ID, BOT_SETTINGS, OPENAI_API_KEY
except ImportError:
    logger.error("Не найден файл конфигурации!")
    sys.exit(1)

try:
    from products_knowledge import (
        PRODUCTS, find_product, get_all_products, get_all_categories,
        format_product_info, format_catalog, search_by_price_range
    )
except ImportError:
    logger.error("Не найдена база знаний товаров!")
    sys.exit(1)

# ═══════════════════════════════════════════════════════════════
# СТРУКТУРЫ ДАННЫХ
# ═══════════════════════════════════════════════════════════════

@dataclass
class CartItem:
    """Элемент корзины"""
    product_id: str
    name: str
    weight: str
    price: float
    quantity: int = 1
    
    @property
    def total(self) -> float:
        return self.price * self.quantity

@dataclass
class UserSession:
    """Сессия пользователя"""
    user_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    cart: List[CartItem] = field(default_factory=list)
    state: str = "start"  # start, browsing, ordering, checkout
    last_activity: datetime = field(default_factory=datetime.now)

# ═══════════════════════════════════════════════════════════════
# AI ENGINE
# ═══════════════════════════════════════════════════════════════

class AIResponseEngine:
    """
    AI-движок для генерации умных ответов на основе
    базы знаний товаров.
    """
    
    # Ключевые слова для определения интента
    INTENTS = {
        "greeting": ["привет", "здравствуй", "здравствуйте", "добрый", "доброе", "hello", "hi", "hey"],
        "goodbye": ["пока", "до свидания", "до встречи", "bye", "goodbye"],
        "catalog": ["каталог", "меню", "товары", "что у вас есть", "ассортимент", "показать", "посмотреть"],
        "price": ["цена", "стоимость", "сколько стоит", "цены", "стоимость"],
        "order": ["заказать", "купить", "оформить", "хочу", "нужно", "заказ"],
        "delivery": ["доставка", "доставить", "курьер", "транспорт", "отправка"],
        "caviar": ["икра", "красная икра", "черная икра", "кета", "форель", "горбуша", "осетр", "белуга"],
        "crab": ["краб", "king crab", "kingkrab", "blue crab", "королевский"],
        "lobster": ["лобстер", "раки", "рак"],
        "snack_box": ["снек", "бокс", "микс", "набор", "сет"],
        "availability": ["наличие", "есть в наличии", "в наличии", "есть ли", "можете"],
        "thanks": ["спасибо", "благодарю", "благодарность", "thanks"],
        "help": ["помощь", "help", "помоги", "не понял", "не понимаю"]
    }
    
    def __init__(self):
        self.products = get_all_products()
        self.categories = get_all_categories()
    
    def detect_intent(self, message: str) -> List[str]:
        """Определить интент(ы) сообщения"""
        message_lower = message.lower()
        intents = []
        
        for intent, keywords in self.INTENTS.items():
            for keyword in keywords:
                if keyword in message_lower:
                    if intent not in intents:
                        intents.append(intent)
                    break
        
        return intents if intents else ["unknown"]
    
    def find_products_in_message(self, message: str) -> List:
        """Найти товары, упоминаемые в сообщении"""
        found = []
        message_lower = message.lower()
        
        for product in self.products:
            for keyword in product.get("keywords", []):
                if keyword.lower() in message_lower:
                    if product not in found:
                        found.append(product)
                    break
        
        return found
    
    def generate_response(self, message: str, user_name: Optional[str] = None) -> str:
        """
        Основная функция генерации ответа на основе ИИ
        """
        message = message.strip()
        intents = self.detect_intent(message)
        found_products = self.find_products_in_message(message)
        
        # Форматируем имя пользователя
        name_part = f", {user_name}!" if user_name else "!"
        
        # ═══════════════════════════════════════════════════════
        # ПРИВЕТСТВИЕ
        # ═══════════════════════════════════════════════════════
        if "greeting" in intents:
            return f"""
🦞 Добрый день{name_part}

Рад вас видеть в *Naxvat SeaFood*! 

Мы специализируемся на премиальных морепродуктах:
• Красная и черная икра
• Свежие раки и лобстеры
• Крабы King Crab, Blue Crab
• Снек-боксы с морепродуктами
• Премиальная таранька

Чем могу помочь? Можете:
• Спросить про конкретный товар
• Узнать цены
• Заказать доставку
• Посмотреть каталог
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # ПРОЩАНИЕ
        # ═══════════════════════════════════════════════════════
        if "goodbye" in intents:
            return f"""
До встречи{name_part} Спасибо за обращение в Naxvat SeaFood! 🦞

Ждём вас снова за лучшими морепродуктами!

📱 Заказ: @naxvatseafood_manager
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # БЛАГОДАРНОСТЬ
        # ═══════════════════════════════════════════════════════
        if "thanks" in intents:
            return f"""
Пожалуйста{name_part} Рады были помочь! 

Если возникнут вопросы — всегда обращайтесь! 🦞

📱 @naxvatseafood_manager
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # КАТАЛОГ
        # ═══════════════════════════════════════════════════════
        if "catalog" in intents:
            return f"""
📋 *Каталог Naxvat SeaFood*

"""
        
        # ═══════════════════════════════════════════════════════
        # НАЛИЧИЕ
        # ═══════════════════════════════════════════════════════
        if "availability" in intents and found_products:
            product_names = ", ".join([p["name"] for p in found_products[:3]])
            return f"""
✅ *{product_names}* — в наличии!

Цены и актуальные остатки уточняйте, так как товар пользуется высоким спросом. 🦞

Для заказа: @naxvatseafood_manager
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # КОНКРЕТНЫЕ ТОВАРЫ
        # ═══════════════════════════════════════════════════════
        if found_products:
            response_parts = []
            for product in found_products[:5]:  # Максимум 5 товаров
                response_parts.append(f"""
📦 *{product['name']}*
   📊 Фасовка: {product['weight']}
   💰 Цена: {product['price']} zł

_{product.get('description', '')}_
""".strip())
            
            return """
{products}

━━━━━━━━━━━━━━━━━━━━
Для оформления заказа напишите @naxvatseafood_manager или нажмите кнопку "Оформить заказ"!

💡 Хотите узнать о других товарах?
            """.strip().format(products="\n".join(response_parts))
        
        # ═══════════════════════════════════════════════════════
        # ИКРА
        # ═══════════════════════════════════════════════════════
        if "caviar" in intents:
            return f"""
🐟 *Красная икра* — наш хит продаж!

📊 *Икра кети Премиум:*
   • 100г — 95 zł
   • 250г — 250 zł
   • 500г — 470 zł

📊 *Икра форели Премиум:*
   • 250г — 160 zł
   • 500г — 305 zł

📊 *Икра горбуши Премиум:*
   • 100г — 90 zł
   • 250г — 230 zł
   • 500г — 420 zł

━━━━━━━━━━━━━━━━━━━━
✨ *Без консервантов:*
   • Кета 1кг — 880 zł
   • Кижуч 1кг — 850 zл
   • Горбуша 1кг — 800 zł
   • Форель 1кг — 530 zł

📱 Заказ: @naxvatseafood_manager
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # КРАБЫ
        # ═══════════════════════════════════════════════════════
        if "crab" in intents:
            return f"""
🦀 *Крабы премиум*

📊 *King Crab — первая фаланга:*
   • 250г — 289 zł
   • 400г — 444 zł
   • 520г — 599 zł
   • 720г — 779 zł

📊 *Blue Crab meat:*
   • 454г — 170 zł

📊 *Другие крабы:*
   • Клешни снежного краба — 240 zł/кг
   • Клешни королевского краба — 950 zł/кг
   • Мясо королевского краба — 950 zł/кг

📱 Заказ: @naxvatseafood_manager
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # ЛОБСТЕРЫ И РАКИ
        # ═══════════════════════════════════════════════════════
        if "lobster" in intents:
            return f"""
🦞 *Раки и лобстеры*

📊 *Раки живые:*
   • 190/240 (за штуку) — 190 zł/кг
   • Варка — +39-70 zł/кг

📊 *Лобстеры (Канада/ЕС):*
   • 350-400г — 250 zł/кг
   • 500-800г — 360 zł/кг
   • 1кг+ — 410 zł/кг
   • Варка — +20 zł/кг

Только свежие! 🦞

📱 Заказ: @naxvatseafood_manager
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # СНЕК-БОКСЫ
        # ═══════════════════════════════════════════════════════
        if "snack_box" in intents:
            return f"""
📦 *Снек-боксы* — готовые наборы!

💰 *Бюджетные:*
   • 100 zł — 1кг
   • 150 zł — 1.5кг
   • 200 zł — 2кг

⭐ *Премиум:*
   • Arriwa — 2.5кг за 250 zł
   • MAX — 2.3кг+ за 250 zł (ВСЕ включено!)

🎁 *В боксах:* крабовые палочки, кальмары, тунец, лосось, анчоусы и многое другое!

📱 Заказ: @naxvatseafood_manager
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # ЦЕНА/СТОИМОСТЬ
        # ═══════════════════════════════════════════════════════
        if "price" in intents or "order" in intents:
            return f"""
💰 *Цены на популярные товары:*

📊 *Икра:*
   • Кета 100г — 95 zł
   • Форель 250г — 160 zł
   • Горбуша 500г — 420 zł

📊 *Морепродукты:*
   • Хвосты лангустов — 550 zł/кг
   • King Crab 250г — 289 zł
   • Клешни снежного краба — 240 zł/кг

📊 *Снек-боксы:*
   • Миксбокс 950г — 120 zł
   • Бокс 200 zł — 2кг

━━━━━━━━━━━━━━━━━━━━
Для точного расчёта заказа напишите @naxvatseafood_manager!
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # ДОСТАВКА
        # ═══════════════════════════════════════════════════════
        if "delivery" in intents:
            return f"""
🚚 *Доставка по всей Польше!*

📦 При заказе от 500 zł — *бесплатная доставка*! 🎁

📍 Возможен самовывоз.

💰 Доставка рассчитывается индивидуально в зависимости от объёма.

📱 Для расчёта доставки напишите @naxvatseafood_manager с указанием города!
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # ПОМОЩЬ
        # ═══════════════════════════════════════════════════════
        if "help" in intents or "unknown" in intents:
            return f"""
🤖 Чем могу помочь{name_part}

Я могу рассказать о:
🐟 Икре (красной и черной)
🦞 Раках и лобстерах
🦀 Крабах (King Crab, Blue Crab)
📦 Снек-боксах
🚚 Доставке
💰 Ценах

━━━━━━━━━━━━━━━━━━━━
📱 *Живой человек:* @naxvatseafood_manager
            """.strip()
        
        # ═══════════════════════════════════════════════════════
        # DEFAULT
        # ═══════════════════════════════════════════════════════
        return f"""
Извините{name_part} Не совсем понял ваш запрос. 🤔

Попробуйте уточнить:
• Какой товар вас интесует?
• Хотите узнать цены?
• Нужна доставка?

Или напишите @naxvatseafood_manager для связи с менеджером! 👨‍💼
        """.strip()


# ═══════════════════════════════════════════════════════════════
# СИСТЕМА УПРАВЛЕНИЯ СЕССИЯМИ
# ═══════════════════════════════════════════════════════════════

class SessionManager:
    """Менеджер сессий пользователей"""
    
    def __init__(self):
        self.sessions: Dict[int, UserSession] = {}
        self.ai_engine = AIResponseEngine()
    
    def get_session(self, user_id: int, username: Optional[str] = None, 
                   first_name: Optional[str] = None) -> UserSession:
        """Получить или создать сессию"""
        if user_id not in self.sessions:
            self.sessions[user_id] = UserSession(
                user_id=user_id,
                username=username,
                first_name=first_name
            )
        else:
            # Обновляем информацию о пользователе
            self.sessions[user_id].username = username
            self.sessions[user_id].first_name = first_name
        
        # Обновляем время активности
        self.sessions[user_id].last_activity = datetime.now()
        
        return self.sessions[user_id]
    
    def get_cart(self, user_id: int) -> List[CartItem]:
        """Получить корзину пользователя"""
        session = self.get_session(user_id)
        return session.cart
    
    def add_to_cart(self, user_id: int, product_id: str, name: str, 
                   weight: str, price: float, quantity: int = 1):
        """Добавить товар в корзину"""
        session = self.get_session(user_id)
        
        # Проверяем, есть ли уже такой товар
        for item in session.cart:
            if item.product_id == product_id:
                item.quantity += quantity
                return
        
        # Добавляем новый товар
        session.cart.append(CartItem(
            product_id=product_id,
            name=name,
            weight=weight,
            price=price,
            quantity=quantity
        ))
    
    def remove_from_cart(self, user_id: int, product_id: str):
        """Удалить товар из корзины"""
        session = self.get_session(user_id)
        session.cart = [item for item in session.cart if item.product_id != product_id]
    
    def update_cart_quantity(self, user_id: int, product_id: str, quantity: int):
        """Обновить количество товара"""
        session = self.get_session(user_id)
        for item in session.cart:
            if item.product_id == product_id:
                if quantity <= 0:
                    session.cart.remove(item)
                else:
                    item.quantity = quantity
                break
    
    def clear_cart(self, user_id: int):
        """Очистить корзину"""
        session = self.get_session(user_id)
        session.cart = []
    
    def get_cart_total(self, user_id: int) -> float:
        """Получить сумму корзины"""
        session = self.get_session(user_id)
        return sum(item.total for item in session.cart)
    
    def format_cart(self, user_id: int) -> str:
        """Форматировать корзину для вывода"""
        session = self.get_session(user_id)
        
        if not session.cart:
            return "🛒 *Корзина пуста*\n\nДобавьте товары из каталога!"
        
        lines = ["🛒 *Ваша корзина:*\n"]
        
        for item in session.cart:
            lines.append(f"• {item.name} ({item.weight})")
            lines.append(f"  {item.quantity} × {item.price} zł = *{item.total} zł*")
            lines.append("")
        
        total = self.get_cart_total(user_id)
        lines.append(f"_Итого: *{total} zł*_")
        
        return "\n".join(lines)
    
    def process_message(self, user_id: int, message: str, 
                       username: Optional[str] = None,
                       first_name: Optional[str] = None) -> str:
        """Обработать сообщение и сгенерировать ответ"""
        session = self.get_session(user_id, username, first_name)
        
        # Обновляем время активности
        session.last_activity = datetime.now()
        
        # Генерируем ответ через AI
        response = self.ai_engine.generate_response(message, first_name)
        
        return response


# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════

def main():
    """Основная функция запуска"""
    logger.info("🚀 Запуск Naxvat SeaFood AI Agent...")
    
    # Проверяем конфигурацию
    if not BOT_TOKEN:
        logger.error("Не указан токен бота!")
        sys.exit(1)
    
    # Инициализируем менеджер сессий
    session_manager = SessionManager()
    
    logger.info("✅ Naxvat SeaFood AI Agent запущен!")
    logger.info(f"📊 Товаров в базе: {len(session_manager.ai_engine.products)}")
    logger.info(f"📁 Категорий: {len(session_manager.ai_engine.categories)}")
    
    # Здесь можно добавить запуск веб-сервера для webhook
    # Или просто использовать polling
    
    print("\n" + "="*50)
    print("🦞 Naxvat SeaFood AI Agent готов к работе!")
    print("="*50)
    print(f"\n📱 Ваш бот: @naxvatseafood_manager")
    print("\n💡 Для полноценной работы необходимо настроить")
    print("   вебхук или запустить polling.\n")


if __name__ == "__main__":
    main()
