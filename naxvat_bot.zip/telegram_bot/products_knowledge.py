# ═══════════════════════════════════════════════════════════════
# Naxvat SeaFood - Product Knowledge Base
# ═══════════════════════════════════════════════════════════════

# Полная база товаров с подробными описаниями для AI-бота

PRODUCTS = {
    # ═══════════════════════════════════════════════════════════
    # КРАСНАЯ ИКРА
    # ═══════════════════════════════════════════════════════════
    "caviar_red": {
        "name": "Красная икра",
        "icon": "🐟",
        "description": "Премиальная красная икра лососевых рыб",
        "products": [
            {
                "id": "caviar_keta_100",
                "name": "Икра кети Премиум",
                "weight": "100г",
                "price": 95,
                "description": "Натуральная икра кети премиум качества",
                "keywords": ["кета", "keta", "икра кети", "красная икра", "100г"]
            },
            {
                "id": "caviar_keta_250",
                "name": "Икра кети Премиум",
                "weight": "250г",
                "price": 250,
                "description": "Икра кети в удобной упаковке 250г",
                "keywords": ["кета", "keta", "250 грамм", "250г"]
            },
            {
                "id": "caviar_keta_500",
                "name": "Икра кети Премиум",
                "weight": "500г",
                "price": 470,
                "description": "Большая упаковка икры кети — выгодно!",
                "keywords": ["кета", "keta", "500 грамм", "500г", "0.5кг"]
            },
            {
                "id": "caviar_forel_250",
                "name": "Икра форели Премиум",
                "weight": "250г",
                "price": 160,
                "description": "Икра форели — нежный вкус",
                "keywords": ["форель", "forel", "икра форели", "форелевая"]
            },
            {
                "id": "caviar_forel_500",
                "name": "Икра форели Премиум",
                "weight": "500г",
                "price": 305,
                "description": "Икра форели 500г — отличный выбор",
                "keywords": ["форель", "500 грамм"]
            },
            {
                "id": "caviar_gorbusha_100",
                "name": "Икра горбуши Премиум",
                "weight": "100г",
                "price": 90,
                "description": "Икра горбуши — классика",
                "keywords": ["горбуша", "gorbusha", "икра горбуши"]
            },
            {
                "id": "caviar_gorbusha_250",
                "name": "Икра горбуши Премиум",
                "weight": "250г",
                "price": 230,
                "description": "Икра горбуши в удобной упаковке",
                "keywords": ["горбуша", "250 грамм"]
            },
            {
                "id": "caviar_gorbusha_500",
                "name": "Икра горбуши Премиум",
                "weight": "500г",
                "price": 420,
                "description": "Большая упаковка икры горбуши",
                "keywords": ["горбуша", "500 грамм"]
            },
            {
                "id": "caviar_kijuch_250",
                "name": "Икра кижуча Премиум",
                "weight": "250г",
                "price": 280,
                "description": "Редкая икра кижуча — премиум",
                "keywords": ["кижуч", "kijuch", "икра кижуча"]
            },
            {
                "id": "caviar_keta_natural_1kg",
                "name": "Икра Кета без консерванта",
                "weight": "1кг",
                "price": 880,
                "description": "Натуральная икра кети БЕЗ консервантов!",
                "keywords": ["натуральная", "без консерванта", "без консервантов", "1 кг", "1000г"]
            },
            {
                "id": "caviar_kijuch_natural_1kg",
                "name": "Икра Кижуч без консерванта",
                "weight": "1кг",
                "price": 850,
                "description": "Натуральная икра кижуча — чистый продукт",
                "keywords": ["натуральная", "без консерванта"]
            },
            {
                "id": "caviar_gorbusha_natural_1kg",
                "name": "Икра Горбуша без консерванта",
                "weight": "1кг",
                "price": 800,
                "description": "Натуральная икра горбуши — для гурманов",
                "keywords": ["натуральная", "без консерванта"]
            },
            {
                "id": "caviar_keta_2sort_1kg",
                "name": "Икра Кета 2 сорт без консерванта",
                "weight": "1кг",
                "price": 500,
                "description": "Икра кети 2 сорт — эконом-вариант",
                "keywords": ["2 сорт", "второй сорт", "дешевле"]
            },
            {
                "id": "caviar_forel_natural_1kg",
                "name": "Икра Форель без консерванта",
                "weight": "1кг",
                "price": 530,
                "description": "Натуральная икра форели — премиум",
                "keywords": ["натуральная", "без консерванта"]
            },
            {
                "id": "caviar_forel_natural_500",
                "name": "Икра Форель без консерванта",
                "weight": "500г",
                "price": 280,
                "description": "Натуральная икра форели 500г",
                "keywords": ["натуральная", "без консерванта", "500 грамм"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # ЧЁРНАЯ ИКРА
    # ═══════════════════════════════════════════════════════════
    "caviar_black": {
        "name": "Черная икра",
        "icon": "🐟",
        "description": "Элитная черная икра осетровых пород",
        "products": [
            {
                "id": "caviar_osetr_50",
                "name": "Икра осетра",
                "weight": "50г",
                "price": 250,
                "description": "Черная икра осетра — классика",
                "keywords": ["осетр", "osetr", "черная икра", "50 грамм"]
            },
            {
                "id": "caviar_osetr_100",
                "name": "Икра осетра",
                "weight": "100г",
                "price": 450,
                "description": "Икра осетра 100г — оптимальный выбор",
                "keywords": ["осетр", "100 грамм"]
            },
            {
                "id": "caviar_beluga_50",
                "name": "Икра амурской белуги",
                "weight": "50г",
                "price": 450,
                "description": "Редкая икра амурской белуги",
                "keywords": ["белуга", "beluga", "амурская", "амур"]
            },
            {
                "id": "caviar_beluga_100",
                "name": "Икра амурской белуги",
                "weight": "100г",
                "price": 850,
                "description": "Икра белуги — премиум",
                "keywords": ["белуга", "100 грамм"]
            },
            {
                "id": "caviar_huso_50",
                "name": "Икра белуги Huso Huso",
                "weight": "50г",
                "price": 550,
                "description": "Элитная икра Huso Huso",
                "keywords": ["huso", "huso huso", "элитная"]
            },
            {
                "id": "caviar_golets_250",
                "name": "Икра гольца",
                "weight": "250г",
                "price": 230,
                "description": "Икра гольца — необычный вкус",
                "keywords": ["голец", "golets"]
            },
            {
                "id": "caviar_shhyka_100",
                "name": "Икра щуки",
                "weight": "100г",
                "price": 108,
                "description": "Икра щуки — бюджетный вариант",
                "keywords": ["щука", "shhyka"]
            },
            {
                "id": "caviar_moyva_200",
                "name": "Икра мойвы",
                "weight": "200г",
                "price": 40,
                "description": "Самая доступная икра!",
                "keywords": ["мойва", "moyva", "дешевая"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # РАКИ
    # ═══════════════════════════════════════════════════════════
    "crayfish": {
        "name": "Раки",
        "icon": "🦞",
        "description": "Свежие живые раки",
        "products": [
            {
                "id": "crayfish_190_240",
                "name": "Раки живые 190/240",
                "weight": "1кг",
                "price": 190,
                "description": "Раки 190-240г за штуку — стандарт",
                "keywords": ["раки", "crayfish", "живые раки", "190/240"]
            },
            {
                "id": "crayfish_boiled_basic",
                "name": "Раки вареные",
                "weight": "1кг",
                "price": 239,
                "description": "Раки с варкой — классика",
                "keywords": ["вареные раки", "готовые"]
            },
            {
                "id": "crayfish_boiled_premium",
                "name": "Раки вареные премиум",
                "weight": "1кг",
                "price": 270,
                "description": "Раки премиум варки",
                "keywords": ["премиум", "дорогие"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # ЛОБСТЕРЫ
    # ═══════════════════════════════════════════════════════════
    "lobster": {
        "name": "Лобстеры",
        "icon": "🦞",
        "description": "Живые лобстеры из Канады и ЕС",
        "products": [
            {
                "id": "lobster_350_400",
                "name": "Лобстеры 350-400г",
                "weight": "1кг",
                "price": 250,
                "description": "Лобстеры среднего размера 350-400г",
                "keywords": ["лобстер", "lobster", "350", "400", "средние"]
            },
            {
                "id": "lobster_500_800",
                "name": "Лобстеры 500-800г",
                "weight": "1кг",
                "price": 360,
                "description": "Крупные лобстеры 500-800г",
                "keywords": ["500", "800", "крупные", "большие"]
            },
            {
                "id": "lobster_1kg_plus",
                "name": "Лобстеры 1кг+",
                "weight": "1кг",
                "price": 410,
                "description": "Огромные лобстеры более 1кг",
                "keywords": ["1кг", "1000г", "огромные", "гигант"]
            },
            {
                "id": "lobster_boil",
                "name": "Варка лобстера",
                "weight": "1кг",
                "price": 20,
                "description": "Услуга варки лобстера",
                "keywords": ["варка", "сварить", "приготовить"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # ЗАМОРОЖЕННЫЕ МОРЕПРОДУКТЫ
    # ═══════════════════════════════════════════════════════════
    "frozen_seafood": {
        "name": "Замороженные морепродукты",
        "icon": "🦐",
        "description": "Премиальные замороженные морепродукты",
        "products": [
            {
                "id": "langust_tails",
                "name": "Хвосты лангустов",
                "weight": "1кг",
                "price": 550,
                "description": "Хвосты лангустов — деликатес",
                "keywords": ["лангуст", "langust", "хвосты"]
            },
            {
                "id": "crab_snow_legs",
                "name": "Клешни снежного краба",
                "weight": "1кг",
                "price": 240,
                "description": "Клешни снежного краба",
                "keywords": ["снежный краб", "snow crab", "клешни"]
            },
            {
                "id": "crab_king_legs",
                "name": "Клешни королевского краба",
                "weight": "1кг",
                "price": 950,
                "description": "Клешни King Crab — топ",
                "keywords": ["королевский краб", "king crab", "краб"]
            },
            {
                "id": "scallops_roe",
                "name": "Гребенцы с икрой",
                "weight": "1кг",
                "price": 180,
                "description": "Морские гребешки с икрой",
                "keywords": ["гребенцы", "гребешки", "scallops"]
            },
            {
                "id": "crab_king_meat",
                "name": "Мясо королевского краба",
                "weight": "1кг",
                "price": 950,
                "description": "Чистое мясо King Crab",
                "keywords": ["мясо краба", "крабовое мясо"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # ПЕЧЕНЬ ТРЕСКИ
    # ═══════════════════════════════════════════════════════════
    "cod_liver": {
        "name": "Печень трески",
        "icon": "🐟",
        "description": "Печень трески из Норвегии",
        "products": [
            {
                "id": "cod_liver_500",
                "name": "Печень трески Норвегия",
                "weight": "500г",
                "price": 125,
                "description": "Печень трески 500г",
                "keywords": ["печень трески", "cod liver", "норвегия"]
            },
            {
                "id": "cod_liver_350",
                "name": "Печень трески Норвегия",
                "weight": "350г",
                "price": 99,
                "description": "Печень трески 350г",
                "keywords": ["350 грамм", "маленькая"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # KING KRAB
    # ═══════════════════════════════════════════════════════════
    "king_crab": {
        "name": "King Krab",
        "icon": "🦀",
        "description": "King Crab — первая фаланга",
        "products": [
            {
                "id": "king_crab_250",
                "name": "King Krab первая фаланга",
                "weight": "250г",
                "price": 289,
                "description": "King Crab 250г",
                "keywords": ["king crab", "kingkrab", "фаланга"]
            },
            {
                "id": "king_crab_400",
                "name": "King Krab первая фаланга",
                "weight": "400г",
                "price": 444,
                "description": "King Crab 400г",
                "keywords": ["400 грамм"]
            },
            {
                "id": "king_crab_520",
                "name": "King Krab первая фаланга",
                "weight": "520г",
                "price": 599,
                "description": "King Crab 520г",
                "keywords": ["520 грамм", "0.5кг"]
            },
            {
                "id": "king_crab_720",
                "name": "King Krab первая фаланга",
                "weight": "720г",
                "price": 779,
                "description": "King Crab 720г — премиум",
                "keywords": ["720 грамм", "0.7кг", "большой"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # BLUE CRAB
    # ═══════════════════════════════════════════════════════════
    "blue_crab": {
        "name": "Blue Crab",
        "icon": "🦀",
        "description": "Blue Crab мясо",
        "products": [
            {
                "id": "blue_crab_meat",
                "name": "Blue Crab meat",
                "weight": "454г",
                "price": 170,
                "description": "Blue Crab мясо в банке 454г",
                "keywords": ["blue crab", "голубой краб", "454"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # СОБСТВЕННОЕ ПРОИЗВОДСТВО
    # ═══════════════════════════════════════════════════════════
    "own_production": {
        "name": "Собственное производство",
        "icon": "🐟",
        "description": "Скумбрия собственного посола",
        "products": [
            {
                "id": "mackerel_salted",
                "name": "Скумбрия собственная посолка",
                "weight": "1кг",
                "price": 49.99,
                "description": "Скумбрия собственного посола — хит продаж!",
                "keywords": ["скумбрия", "mackerel", "соленая", "посол"]
            },
            {
                "id": "mackerel_onion",
                "name": "Скумбрия с луком нарезка",
                "weight": "1кг",
                "price": 59.99,
                "description": "Скумбрия с луком, нарезанная",
                "keywords": ["с луком", "нарезанная", "порезанная"]
            },
            {
                "id": "mackerel_frozen",
                "name": "Скумбрия свежемороженая",
                "weight": "1кг",
                "price": 29.99,
                "description": "Скумбрия свежемороженая",
                "keywords": ["свежемороженая", "замороженная"]
            },
            {
                "id": "mackerel_marinated",
                "name": "Скумбрия маринованная",
                "weight": "1кг",
                "price": 39.99,
                "description": "Скумбрия маринованная для запекания",
                "keywords": ["маринованная", "для запекания"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # СНЕК-БОКСЫ
    # ═══════════════════════════════════════════════════════════
    "snack_boxes": {
        "name": "Снек-боксы",
        "icon": "📦",
        "description": "Готовые наборы морепродуктов",
        "products": [
            {
                "id": "mixbox_950",
                "name": "Миксбокс 950г",
                "weight": "950г",
                "price": 120,
                "description": "Миксбокс 950г — хит!",
                "keywords": ["миксбокс", "mixbox", "микс"]
            },
            {
                "id": "snack_100g",
                "name": "Снек 100г (для микса)",
                "weight": "100г",
                "price": 12,
                "description": "Снек 100г для самостоятельного микса",
                "keywords": ["снек", "100 грамм", "на развес"]
            },
            {
                "id": "box_200",
                "name": "Снек бокс 200 злотых",
                "weight": "2кг",
                "price": 200,
                "description": "Снек бокс на 200 zł — оптимальный",
                "keywords": ["200 злотых", "200 pln", "набор"]
            },
            {
                "id": "box_150",
                "name": "Снек бокс 150 злотых",
                "weight": "1.5кг",
                "price": 150,
                "description": "Снек бокс на 150 zł",
                "keywords": ["150 злотых", "150 pln"]
            },
            {
                "id": "box_100",
                "name": "Снек бокс 100 злотых",
                "weight": "1кг",
                "price": 100,
                "description": "Снек бокс на 100 zł — стартовый",
                "keywords": ["100 злотых", "100 pln"]
            },
            {
                "id": "box_arriwa",
                "name": "Снек бокс Arriwa",
                "weight": "2.5кг",
                "price": 250,
                "description": "Премиум бокс Arriwa — лучший!",
                "keywords": ["arriwa", "аррива", "премиум", "дорогой"]
            },
            {
                "id": "box_fisher",
                "name": "Снек бокс Рыбалка",
                "weight": "2кг",
                "price": 200,
                "description": "Тематический бокс Рыбалка",
                "keywords": ["рыбалка", "fisher"]
            },
            {
                "id": "box_krabstime",
                "name": "Снек бокс KrabsTime",
                "weight": "2кг",
                "price": 200,
                "description": "Бокс KrabsTime — для крабоманов",
                "keywords": ["krabs", "krabstime", "краб"]
            },
            {
                "id": "box_squid_game",
                "name": "Снек бокс Игра в кальмара",
                "weight": "2кг",
                "price": 200,
                "description": "Тематический бокс по сериалу",
                "keywords": ["кальмар", "squid game", "игра в кальмара"]
            },
            {
                "id": "box_fish",
                "name": "Снек бокс Рыбный",
                "weight": "2кг",
                "price": 200,
                "description": "Рыбный снек бокс",
                "keywords": ["рыба", "рыбный"]
            },
            {
                "id": "box_sea",
                "name": "Снек бокс Морские",
                "weight": "2кг",
                "price": 200,
                "description": "Морской снек бокс",
                "keywords": ["море", "морские"]
            },
            {
                "id": "box_beer",
                "name": "Снек бокс Пивная тарелка",
                "weight": "2кг",
                "price": 200,
                "description": "Идеально под пиво! 🍺",
                "keywords": ["пиво", "пивной", "beer"]
            },
            {
                "id": "box_red",
                "name": "Снек бокс Рыжий",
                "weight": "2кг",
                "price": 200,
                "description": "Снек бокс Рыжий",
                "keywords": ["рыжий", "рыжий бокс"]
            },
            {
                "id": "box_max",
                "name": "Снек бокс 250 злотых MAX",
                "weight": "2.5кг",
                "price": 250,
                "description": "МАКСИМАЛЬНЫЙ бокс — 2.3кг+ всего за 250 zł!",
                "keywords": ["250 злотых", "250 pln", "максимальный", "max", "все включено"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # ПРЕМИАЛЬНАЯ ТАРАНЬКА
    # ═══════════════════════════════════════════════════════════
    "premium_dried_fish": {
        "name": "Премиальная таранька",
        "icon": "🐟",
        "description": "Вяленая рыба премиум качества",
        "products": [
            {
                "id": "roach_ichnye",
                "name": "Лящи Икряные",
                "weight": "1кг",
                "price": 148,
                "description": "Лящи с икрой — премиум",
                "keywords": ["лящ", "лящи", "ichnye"]
            },
            {
                "id": "roach_s_small",
                "name": "Плотва Икряная S",
                "weight": "1кг",
                "price": 120,
                "description": "Плотва S с икрой",
                "keywords": ["плотва", "roach", "маленькая"]
            },
            {
                "id": "roach_s_medium",
                "name": "Плотва Икряная M",
                "weight": "1кг",
                "price": 160,
                "description": "Плотва M с икрой",
                "keywords": ["средняя"]
            },
            {
                "id": "roach_s_large",
                "name": "Плотва Икряная L",
                "weight": "1кг",
                "price": 180,
                "description": "Плотва L с икрой",
                "keywords": ["большая"]
            },
            {
                "id": "roach_no_scale_m",
                "name": "Плотва Икряная без чешуи M",
                "weight": "1кг",
                "price": 170,
                "description": "Плотва без чешуи",
                "keywords": ["без чешуи", "очищенная"]
            },
            {
                "id": "roach_no_scale_xl",
                "name": "Плотва мега Икряная XL",
                "weight": "1кг",
                "price": 230,
                "description": "Мега плотва XL — самая большая!",
                "keywords": ["xl", "мега", "огромная"]
            },
            {
                "id": "pike_dried",
                "name": "Щука",
                "weight": "1кг",
                "price": 109,
                "description": "Вяленая щука",
                "keywords": ["щука", "pike"]
            },
            {
                "id": "perch_dried",
                "name": "Судак",
                "weight": "1кг",
                "price": 119,
                "description": "Вяленый судак",
                "keywords": ["судак", "perch"]
            },
            {
                "id": "gobies",
                "name": "Бички черноморские",
                "weight": "1кг",
                "price": 110,
                "description": "Черноморские бички",
                "keywords": ["бички", "черноморские", "gobies"]
            },
            {
                "id": "smelt_50_50",
                "name": "Корюшка с икорой 50/50",
                "weight": "1кг",
                "price": 180,
                "description": "Корюшка 50% + икра 50%",
                "keywords": ["корюшка", "smelt", "50 на 50"]
            },
            {
                "id": "smelt_zubatka",
                "name": "Корюшка зубатка Икряная",
                "weight": "1кг",
                "price": 510,
                "description": "Премиум корюшка зубатка",
                "keywords": ["зубатка", "zubatka", "дорогая"]
            },
            {
                "id": "yolka_keta",
                "name": "Юкола из кеты",
                "weight": "1кг",
                "price": 255,
                "description": "Юкола из кеты — вяленая рыба",
                "keywords": ["юкола", "yolka", "вяленая"]
            },
            {
                "id": "yolka_salmon",
                "name": "Юкола из лосося",
                "weight": "1кг",
                "price": 255,
                "description": "Юкола из лосося",
                "keywords": ["лосось", "salmon", "семга"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # ВЯЛЕНАЯ ИКРА
    # ═══════════════════════════════════════════════════════════
    "dried_roe": {
        "name": "Вяленая икра",
        "icon": "🥢",
        "description": "Натуральная вяленая икра",
        "products": [
            {
                "id": "roe_perch_dried",
                "name": "Икра судака",
                "weight": "100г",
                "price": 24,
                "description": "Вяленая икра судака",
                "keywords": ["судак", "perch", "вяленая"]
            },
            {
                "id": "roe_trout_dried",
                "name": "Икра форели",
                "weight": "100г",
                "price": 35,
                "description": "Вяленая икра форели",
                "keywords": ["форель", "trout", "вяленая"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # КОПЧЕНОСТИ
    # ═══════════════════════════════════════════════════════════
    "smoked": {
        "name": "Копчености",
        "icon": "🔥",
        "description": "Копченые морепродукты",
        "products": [
            {
                "id": "roll_3fish",
                "name": "Рулет из 3 рыб",
                "weight": "1кг",
                "price": 238,
                "description": "Рулет из трёх видов рыб",
                "keywords": ["рулет", "3 рыбы", "микс"]
            },
            {
                "id": "roll_squid",
                "name": "Рулет с кальмаром",
                "weight": "1кг",
                "price": 266,
                "description": "Рулет с кальмаром",
                "keywords": ["кальмар", "squid"]
            },
            {
                "id": "cheese_braid",
                "name": "Сыр косичка",
                "weight": "100г",
                "price": 12,
                "description": "Сыр косичка — закуска",
                "keywords": ["сыр", "косичка"]
            },
            {
                "id": "mackerel_smoked",
                "name": "Скумбрия копченая",
                "weight": "1кг",
                "price": 70,
                "description": "Скумбрия горячего копчения",
                "keywords": ["копченая", "smoked"]
            },
            {
                "id": "yolka_salmon_smoked",
                "name": "Юкола из семги",
                "weight": "1кг",
                "price": 266,
                "description": "Юкола из семги копченая",
                "keywords": ["семга", "salmon", "копченая"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # СУШЕНЫЕ МОРЕПРОДУКТЫ
    # ═══════════════════════════════════════════════════════════
    "dried_seafood": {
        "name": "Сушеные морепродукты",
        "icon": "☀️",
        "description": "Сушеные морепродукты для снеков",
        "products": [
            {
                "id": "mussels_dried",
                "name": "Мидии сушеные",
                "weight": "100г",
                "price": 18,
                "description": "Сушеные мидии",
                "keywords": ["мидии", "mussels"]
            },
            {
                "id": "shrimp_dried_whole",
                "name": "Креветки сушеные целые",
                "weight": "100г",
                "price": 24,
                "description": "Сушеные креветки целые",
                "keywords": ["креветки", "shrimp", "целые"]
            },
            {
                "id": "shrimp_dried_peeled",
                "name": "Креветки сушеные чищеные",
                "weight": "100г",
                "price": 26,
                "description": "Сушеные креветки чищеные",
                "keywords": ["чищеные", "очищенные"]
            }
        ]
    },
    
    # ═══════════════════════════════════════════════════════════
    # СНЕКИ (ПОЗИЦИИ ДЛЯ МИКСА)
    # ═══════════════════════════════════════════════════════════
    "snack_items": {
        "name": "Снеки для микс-боксов",
        "icon": "🍤",
        "description": "Позиции для самостоятельного составления боксов",
        "products": [
            {"id": "snack_anchovies", "name": "Анчоусы", "weight": "100г", "price": 17, "keywords": ["анчоусы", "anchovies"]},
            {"id": "snack_salmon_balls", "name": "Икряники с лососем", "weight": "100г", "price": 17, "keywords": ["икряники", "лосось"]},
            {"id": "snack_pike_fillet", "name": "Филе щуки", "weight": "100г", "price": 17, "keywords": ["щука", "филе"]},
            {"id": "snack_pike_pepper", "name": "Филе щуки с перцем", "weight": "100г", "price": 17, "keywords": ["щука", "перец"]},
            {"id": "snack_octopus", "name": "Осьминог", "weight": "100г", "price": 17, "keywords": ["осьминог", "octopus"]},
            {"id": "snack_squid_striped", "name": "Филе кальмара полосатый", "weight": "100г", "price": 17, "keywords": ["кальмар", "полосатый"]},
            {"id": "snack_golden_fish", "name": "Голден Фиш", "weight": "100г", "price": 17, "keywords": ["голден", "golden"]},
            {"id": "snack_crab_shred", "name": "Стружка краба", "weight": "100г", "price": 17, "keywords": ["краб", "стружка"]},
            {"id": "snack_squid_shred", "name": "Стружка кальмара", "weight": "100г", "price": 17, "keywords": ["кальмар", "стружка"]},
            {"id": "snack_crab_meat", "name": "Мясо краба", "weight": "100г", "price": 17, "keywords": ["краб", "мясо"]},
            {"id": "snack_crab_slice", "name": "Нарезка краба", "weight": "100г", "price": 17, "keywords": ["краб", "нарезка"]},
            {"id": "snack_squid_rings", "name": "Кольца кальмаров", "weight": "100г", "price": 17, "keywords": ["кальмар", "кольца"]},
            {"id": "snack_squid_web", "name": "Паутинка кальмара", "weight": "100г", "price": 17, "keywords": ["кальмар", "паутинка"]},
            {"id": "snack_tuna_premium", "name": "Тунец премиум", "weight": "100г", "price": 17, "keywords": ["тунец", "tuna"]},
            {"id": "snack_squid_shanghai", "name": "Кальмар по-шанхайски", "weight": "100г", "price": 17, "keywords": ["кальмар", "шанхай"]},
            {"id": "snack_trigla", "name": "Тригла", "weight": "100г", "price": 17, "keywords": ["тригла", "trigla"]},
            {"id": "snack_flounder", "name": "Камбала", "weight": "100г", "price": 17, "keywords": ["камбала", "flounder"]},
            {"id": "snack_eel", "name": "Угорь", "weight": "100г", "price": 17, "keywords": ["угорь", "eel"]},
            {"id": "snack_trigla_pepper", "name": "Тригла с перцем", "weight": "100г", "price": 17, "keywords": ["тригла", "перец"]},
            {"id": "snack_squid_sticks", "name": "Крабовые палочки из кальмара", "weight": "100г", "price": 17, "keywords": ["палочки", "кальмар"]},
            {"id": "snack_ichnyki", "name": "Икряники", "weight": "100г", "price": 17, "keywords": ["икряники"]},
            {"id": "snack_nerka_teriyaki", "name": "Нерка в терияки", "weight": "100г", "price": 17, "keywords": ["нерка", "teriyaki", "терияки"]},
            {"id": "snack_keta_teriyaki", "name": "Кета в терияки", "weight": "100г", "price": 17, "keywords": ["кета", "терияки"]}
        ]
    }
}

# ═══════════════════════════════════════════════════════════════
# ФУНКЦИИ ПОИСКА ТОВАРОВ
# ═══════════════════════════════════════════════════════════════

def find_product(query):
    """Найти товар по поисковому запросу"""
    query = query.lower()
    
    for category_id, category in PRODUCTS.items():
        for product in category["products"]:
            # Проверяем ключевые слова
            for keyword in product.get("keywords", []):
                if keyword.lower() in query:
                    return product, category
    
    return None, None


def get_all_products():
    """Получить все товары"""
    result = []
    for category_id, category in PRODUCTS.items():
        for product in category["products"]:
            product_copy = product.copy()
            product_copy["category"] = category["name"]
            product_copy["category_id"] = category_id
            result.append(product_copy)
    return result


def get_products_by_category(category_id):
    """Получить товары категории"""
    if category_id in PRODUCTS:
        return PRODUCTS[category_id]["products"]
    return []


def get_all_categories():
    """Получить все категории"""
    return [
        {"id": k, "name": v["name"], "icon": v["icon"], "count": len(v["products"])}
        for k, v in PRODUCTS.items()
    ]


def format_product_info(product, category):
    """Форматировать информацию о товаре"""
    return f"{category['icon']} **{product['name']}**\n" \
           f"📦 Фасовка: {product['weight']}\n" \
           f"💰 Цена: {product['price']} zł\n\n" \
           f"_{product.get('description', '')}_"


def format_catalog():
    """Форматировать каталог для вывода"""
    result = "📋 *Каталог Naxvat SeaFood*\n\n"
    
    for category_id, category in PRODUCTS.items():
        result += f"{category['icon']} *{category['name']}*\n"
        for product in category["products"][:3]:  # Первые 3 товара
            result += f"• {product['name']} {product['weight']} — {product['price']} zł\n"
        if len(category["products"]) > 3:
            result += f"└ И ещё {len(category['products']) - 3} позиций...\n"
        result += "\n"
    
    return result


def search_by_price_range(min_price=None, max_price=None):
    """Найти товары в ценовом диапазоне"""
    results = []
    for category_id, category in PRODUCTS.items():
        for product in category["products"]:
            if min_price is not None and product["price"] < min_price:
                continue
            if max_price is not None and product["price"] > max_price:
                continue
            results.append((product, category))
    return results
